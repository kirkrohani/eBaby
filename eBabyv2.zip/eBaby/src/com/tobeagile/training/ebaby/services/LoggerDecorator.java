package com.tobeagile.training.ebaby.services;

import com.tobeagile.training.ebaby.domain.Auction;

public abstract class LoggerDecorator {
	public void process(Auction auction, String fileName) {		
	}
}
