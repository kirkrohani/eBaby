package com.tobeagile.training.ebaby.services;

public interface Hours {
	public boolean isOffHours();
}
