package com.tobeagile.training.ebaby.services;

public interface Auctionable {
	public void handleAuctionEvents(long now);
}
